#!/bin/bash
echo ECS_CLUSTER=prod-ecs-cluster >> /etc/ecs/ecs.config